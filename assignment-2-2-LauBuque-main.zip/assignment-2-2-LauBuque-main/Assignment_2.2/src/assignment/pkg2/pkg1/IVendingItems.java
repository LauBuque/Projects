/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignment.pkg2.pkg1;

/**
 *
 * @author lauriceniabuque
 */
public interface IVendingItems{
    //getters
    String GetName();
    double GetPrice();
}
